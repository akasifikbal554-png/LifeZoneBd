require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const { verifyCsrf } = require('./middleware/csrf');

const uploadsDir = path.join(__dirname, '../uploads');
fs.mkdirSync(uploadsDir, { recursive: true });

const app = express();
app.set('trust proxy', 1);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      mediaSrc: ["'self'", 'https:'],
      connectSrc: ["'self'"]
    }
  }
}));

app.use(rateLimit({ windowMs: 60 * 1000, max: 180 }));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use('/api', verifyCsrf);

// Static Public Frontend & Non-Executable Uploads
app.use('/uploads', express.static(uploadsDir));
app.use(express.static(path.join(__dirname, '../public')));

// API Routes
app.use('/api/auth', require('./routes/auth.routes'));
app.use('/api/member', require('./routes/member.routes'));
app.use('/api/catalog', require('./routes/catalog.routes'));
app.use('/api/billing', require('./routes/billing.routes'));
app.use('/api/support', require('./routes/support.routes'));
app.use('/api/admin', require('./routes/admin.routes'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', platform: 'LifeZoneBD' }));

app.use((err, req, res, next) => {
  console.error(err);
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'Duplicate record already exists.' });
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'Uploaded file exceeds maximum allowed size.' });
  }
  res.status(err.status || 400).json({ error: err.message || 'Unexpected server error.' });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`LifeZoneBD running on http://localhost:${port}`));
