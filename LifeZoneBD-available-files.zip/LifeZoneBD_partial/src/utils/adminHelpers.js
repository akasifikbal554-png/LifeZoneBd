const fs = require('fs/promises');
const path = require('path');
const validator = require('validator');

const UPLOADS_DIR = path.resolve(__dirname, '../../uploads');

function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

function parsePositiveInt(value, fieldName = 'id') {
  const num = Number(value);
  if (!Number.isInteger(num) || num <= 0) {
    const err = new Error(`Invalid ${fieldName}.`);
    err.status = 400;
    throw err;
  }
  return num;
}

function parsePagination(query = {}) {
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit, 10) || 20));
  const offset = (page - 1) * limit;
  const search = typeof query.search === 'string'
    ? query.search.trim().slice(0, 120)
    : (typeof query.q === 'string' ? query.q.trim().slice(0, 120) : '');
  return { page, limit, offset, search };
}

function paginatedJson(res, { items, total, page, limit }) {
  return res.json({
    success: true,
    data: items,
    pagination: {
      page,
      limit,
      total: Number(total || 0),
      total_pages: Math.max(1, Math.ceil(Number(total || 0) / limit))
    }
  });
}

function slugify(input) {
  return String(input || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 180);
}

function isValidSlug(slug) {
  return /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(String(slug || ''));
}

function isValidUrlOrPath(val) {
  if (!val) return true;
  const str = String(val).trim();
  if (str.startsWith('/uploads/')) return true;
  return validator.isURL(str, { protocols: ['http', 'https'], require_protocol: true });
}

async function cleanupUploadedFile(file) {
  if (!file || !file.path) return;
  try {
    const resolved = path.resolve(file.path);
    if (resolved.startsWith(UPLOADS_DIR)) {
      await fs.unlink(resolved);
    }
  } catch {
    // Ignore already-deleted files
  }
}

async function verifyFileMagicBytes(file, { allowPdf = true } = {}) {
  if (!file) return null;

  const fh = await fs.open(file.path, 'r');
  try {
    const buf = Buffer.alloc(12);
    await fh.read(buf, 0, 12, 0);

    const isJpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
    const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
    const isWebp = buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
      buf.subarray(8, 12).toString('ascii') === 'WEBP';
    const isPdf = allowPdf && buf.subarray(0, 4).toString('ascii') === '%PDF';

    if (!isJpeg && !isPng && !isWebp && !isPdf) {
      await cleanupUploadedFile(file);
      const err = new Error(
        allowPdf
          ? 'File signature verification failed. Allowed: JPG, PNG, WEBP, PDF.'
          : 'Image signature verification failed. Allowed: JPG, PNG, WEBP.'
      );
      err.status = 400;
      throw err;
    }

    return `/uploads/${file.filename}`;
  } finally {
    await fh.close();
  }
}

module.exports = {
  asyncHandler,
  parsePositiveInt,
  parsePagination,
  paginatedJson,
  slugify,
  isValidSlug,
  isValidUrlOrPath,
  cleanupUploadedFile,
  verifyFileMagicBytes
};
