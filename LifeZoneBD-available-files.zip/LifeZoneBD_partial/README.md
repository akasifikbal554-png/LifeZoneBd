# LifeZoneBD Platform

Lawful, transparent multi-module web platform built with Node.js, Express, MySQL 8, and Vanilla ES6 SPA.

## Local Installation
1. Install Node.js v20+ and MySQL 8.0+.
2. Import database schema and seed data:
   `mysql -u root -p < database/schema.sql`
   `mysql -u root -p < database/seed.sql`
3. Create environment file:
   `cp .env.example .env` (set `DB_PASSWORD`, `JWT_SECRET`, `CSRF_SECRET`, and `COOKIE_SECURE=false` for local HTTP).
4. Install dependencies & create Super Admin:
   `npm install`
   `npm run create-admin`
5. Start server:
   `npm run dev`
6. Open `http://localhost:4000`
